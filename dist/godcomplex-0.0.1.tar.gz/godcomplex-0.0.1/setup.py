from setuptools import setup

setup(name="godcomplex",
	version="0.0.1",
	description="this will say something if you say god",
	author="Isaac Robinson",
	author_email="isaacrob@me.com",
	license="GNU",
	packages=["godcomplex"],
	keywords=["god","irony","speech recognition"],
	install_requires=['SpeechRecognition','espeak'],
	zip_safe=False)
